﻿using Axis.Model.Common;
using Axis.RuleEngine.Helpers.Results;
using Axis.RuleEngine.Reporting;
using System.Collections.Generic;
using System.Web.Http;
using Axis.Model.ReportingServices;

namespace Axis.RuleEngine.Service.Controllers
{
    public class ReportingController : ApiController
    {
        private readonly IReportingRuleEngine _ReportingRuleEngine = null;

        public ReportingController(IReportingRuleEngine reportingRuleEngine)
        {
            _ReportingRuleEngine = reportingRuleEngine;
        }
        public IHttpActionResult GetReportsByType(string reportTypeName)
        {
            var responseObject = _ReportingRuleEngine.GetReportsByType(reportTypeName);
            return new HttpResult<Response<ReportingServicesModel>>(responseObject, Request);
        }

    }
}
